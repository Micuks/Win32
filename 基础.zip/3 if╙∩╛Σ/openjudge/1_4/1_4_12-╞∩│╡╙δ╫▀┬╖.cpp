#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int s;
int main(){
   scanf("%d",&s);
   if(s / 3.0 + 50 > s/1.2)
    printf("Walk\n");
  else if(s / 3.0 + 50 == s/1.2){
    printf("All\n");
  }
  else
    printf("Bike\n");
   return 0;
}
