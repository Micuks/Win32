#include <stdio.h>
#include <math.h>
int main()
{
double a,b,c,t,ansa,ansb,x,vit;

scanf("%lf %lf %lf",&a,&b,&c);
t=b*b-4*a*c;

if (t>0)
{
ansa=(-b+sqrt(t))/(2*a);
ansb=(-b-sqrt(t))/(2*a);
printf("x1=%.5lf;x2=%.5lf\n",ansa,ansb);
ansa = (-b + sqrt(t)) / (2*a);
ansa = (-b - sqrt(t)) / (2*a);
printf("x1=%.5lf;x2=%.5lf\n",ansa,ansb);
}
if (t==0)
{
printf("x1=x2=%.5lf\n",(-b) / (2*a));
}
if (t<0)
{
x=-b/(2*a);
if (x==-0.0) x=0;
vit=sqrt(-t)/(2*a);
printf("x1=%0.5lf+%0.5lfi;x2=%0.5lf-%0.5lfi\n",x,vit,x,vit);
}
return 0;
}
