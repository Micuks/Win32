#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#define ll long long
using namespace std;
ll x,y;
int main(){
  scanf("%lld%lld",&x,&y);
  if(x > y)
    printf(">\n");
  else if(x == y)
    printf("=\n");
  else
    printf("<\n");
 return 0;
}
