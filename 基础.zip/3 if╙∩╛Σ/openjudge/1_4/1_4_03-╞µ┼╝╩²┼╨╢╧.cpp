#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#define ll long long
using namespace std;
int a;
int main(){
  scanf("%d",&a);
  if(a % 2 == 1)
    printf("odd\n");
  else
    printf("even\n");
 return 0;
}
