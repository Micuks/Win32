#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int main(){
   scanf("%d",&n);
   if(n % 3 == 0 && n %7 ==0 && n % 5==0)
    printf("3 5 7\n");
  else if((n % 3 == 0 && n % 5 ==0 && n % 7 !=0) || (n % 3 == 0 && n % 7 ==0 && n % 5 !=0) ||(n % 5 == 0 && n % 7 ==0 && n % 3 !=0)){
    if(n % 3 ==0 ) printf("3 ");
    if(n % 5 ==0 ) printf("5 ");
    if(n % 7 ==0 ) printf("7 ");
    printf("\n");
  }
  else if(n % 3 !=0 && n % 5 != 0 && n % 7 !=0)
    printf("n\n");
  else{
    if(n % 3 ==0 ) printf("3\n");
    if(n % 5 ==0 ) printf("5\n");
    if(n % 7 ==0 ) printf("7\n");
  }
  return 0;
}
