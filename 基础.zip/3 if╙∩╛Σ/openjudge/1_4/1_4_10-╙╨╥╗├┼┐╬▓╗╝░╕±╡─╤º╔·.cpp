#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int x,y;
int main(){
   scanf("%d%d",&x,&y);
   if(x < 60 && y >60 || (x > 60 && y < 60))
    printf("1\n");
    else
    printf("0\n");
   return 0;
}
