#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,my;
char a;
int main(){
  scanf("%d %c",&n,&a);
  my = 8;
  if(n > 1000){
    my += ceil((n - 1000) / 500.0) * 4;
    // cout<<my<<endl;
  }
  if(a == 'y')
    my += 5;
  printf("%d\n",my);
  return 0;
}
