#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#define ll long long
using namespace std;
double a;
int main(){
  scanf("%lf",&a);
  printf("%0.2lf\n", fabs(a));
 return 0;
}
