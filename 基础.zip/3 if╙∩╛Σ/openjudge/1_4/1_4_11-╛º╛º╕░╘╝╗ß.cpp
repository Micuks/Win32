#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int main(){
   scanf("%d",&n);
   if(n == 1 || n == 3 || n == 5)
    printf("NO\n");
   else
    printf("YES\n");
   return 0;
}
