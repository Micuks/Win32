#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int a,b;
char c;
int main(){
  scanf("%d%d %c",&a,&b,&c);
  if(c == '/' && b == 0){
    printf("Divided by zero!");
    return 0;
  }
  if(c != '+' && c != '-' && c != '*' && c != '/'){
    printf("Invalid operator!");
    return 0;
  }
  if(c == '+')
    printf("%d\n",a + b);
  else if(c == '-')
    printf("%d\n",a - b);
  else if(c == '*')
    printf("%d\n",a * b);
  else
    printf("%d\n",a / b);
  return 0;
}
