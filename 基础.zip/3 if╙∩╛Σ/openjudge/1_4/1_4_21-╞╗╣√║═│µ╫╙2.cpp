#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,x,y;
int main(){
  scanf("%d%d%d",&n,&x,&y);
  int ans = n - int(ceil( y*1.0 / x));
  if(ans < 0) ans = 0;
  printf("%d\n",ans);
  return 0;
}
