#include<iostream>
#include<cstdio>
using namespace std;
int a,b,c;
int main(){
  scanf("%d%d%d",&a,&b,&c);
  int mx = max(a, b);
  mx = max(mx, c);
  printf("%d\n",mx);
  return 0;
}
