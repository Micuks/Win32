#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
//四年一闰,百年不闰,四百年再闰
int a,b,c;
int main(){
  scanf("%d%d%d",&a,&b,&c);
  if(a + b > c && a + c > b && b + c > a){
    printf("yes\n");
  }
  else
    printf("no\n" );
  return 0;
}
