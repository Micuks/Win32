#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#define ll long long
using namespace std;
char a;
int main(){
  scanf("%c",&a);
  if(int(a) % 2 == 1)
    printf("YES\n");
  else
    printf("NO\n");
 return 0;
}
