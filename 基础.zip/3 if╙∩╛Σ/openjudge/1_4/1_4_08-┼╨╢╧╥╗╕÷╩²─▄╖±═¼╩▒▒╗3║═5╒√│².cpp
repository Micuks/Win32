#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int main(){
  scanf("%d",&n);
  if(n % 3 ==0 && n % 5==0)
    printf("YES\n");
  else
    printf("NO\n");
 return 0;
}
