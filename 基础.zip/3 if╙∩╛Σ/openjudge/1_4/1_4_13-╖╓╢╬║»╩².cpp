#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
double x,y;
int main(){
   scanf("%lf",&x);
   if(x < 5 && x >= 0)
     y = -x + 2.5;
   else if(x >= 5 && x < 10)
     y = 2 - 1.5 * (x - 3) * (x - 3);
   else if(x >= 10 && x < 20)
     y = x/2 - 1.5;
    printf("%lf\n",y);
   return 0;
}
