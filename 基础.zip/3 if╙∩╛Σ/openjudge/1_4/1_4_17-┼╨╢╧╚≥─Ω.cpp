#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;

//四年一闰,百年不闰,四百年再闰
int n;
int main(){
  scanf("%d",&n);
  if((n % 4 == 0 && n % 100 != 0) || n % 400 == 0)
    printf("Y\n");
  else
    printf("N\n");
  return 0;
}
