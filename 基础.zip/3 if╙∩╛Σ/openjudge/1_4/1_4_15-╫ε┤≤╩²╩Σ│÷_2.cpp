#include<iostream>
#include<cstdio>
using namespace std;
int a,b,c,mx;
int main(){
  scanf("%d%d%d",&a,&b,&c);
  mx = a;
  if(b > mx) mx = b;
  if(c > mx) mx = c;
  printf("%d\n",mx);
  return 0;
}
