#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int x,y;
int main(){
  scanf("%d",&x);
  if(x >= 10 && y <= 99)
    printf("1\n");
  else
    printf("0\n");
 return 0;
}
