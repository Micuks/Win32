#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
double a,b,c,ansa,ansb,vit,x;
int main(){
  scanf("%lf%lf%lf",&a,&b,&c);
  double t = b*b - 4*a*c;
  if(fabs(t) <= 1e-5){
    printf("x1=x2=%.5lf\n",(-b) / (2*a));
  }
  else if(t > 1e-5){//1.fabs(t)>
    ansa = (-b + sqrt(t)) / (2*a);
    ansb = (-b - sqrt(t)) / (2*a);//2.write to ansa ,not to copy!!!
    printf("x1=%.5lf;x2=%.5lf\n",ansa,ansb);
  }
  else{
    x = (0-b) / (2*a);//3.0 is not -0
    vit = sqrt(-t) / (2*a);
    // cout<<vit<<endl;//1
    printf("x1=%0.5lf+%0.5lfi;x2=%0.5lf-%0.5lfi\n",x,vit,x,vit);
  }
  return 0;
}
//-0
