#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int t;
char s[10005];
int main(){
  scanf("%s",s);
  printf("%d",strlen(s));
  while(scanf("%s",s) != EOF){
    printf(",%d",strlen(s));
  }
  return 0;
}
