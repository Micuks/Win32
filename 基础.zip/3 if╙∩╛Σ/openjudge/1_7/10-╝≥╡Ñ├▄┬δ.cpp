// o p q r s t  u  v   w  x  y  z
//             21  22  23 24 25 26
// a b c d e f
// 1 2 3 4 5 6
// 1 - 5 = -4 + 26 = 22
#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char c;
int main(){
  c = getchar();
  while(c != '\n'){
    if(c >= 'A' && c <= 'Z'){
      // printf("%d\n",c );
      if(c - 64 - 5 <= 0)// forget =
        printf("%c",c - 5 + 26);
      else
        printf("%c",c - 5);
    }
    else
      printf("%c",c);
    c = getchar();
  }
  return 0;
}
