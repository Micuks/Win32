#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[85],b[85],sa[35],sb[35];
int main(){
  scanf("%s%s",a,b);
  strcat(sa,a);strcat(sa,a);
  strcat(sb,b);strcat(sb,b);
  if(strstr(sa,a)){
    printf("true\n");return 0;
  }
  if(strstr(sb,b)){
    printf("true\n");return 0;
  }
  printf("false\n");
  return 0;
}
