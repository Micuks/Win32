#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s[25];
int main(){
  scanf("%s",s+1);
  int len = strlen(s+1);
  for(int i = 1; i <= len; i++){
    if(s[1] >= '0' && s[1] <= '9'){
      printf("no\n");return 0;
    }
    else if(!(s[i] >= 'A' && s[i] <= 'Z') && !(s[i] >= 'a' && s[i] <= 'z') && !(s[i] >= '0' && s[i] <= '9') && s[i] != '_'){
      printf("no\n");return 0;
    }
  }
  printf("yes\n");
  return 0;
}
