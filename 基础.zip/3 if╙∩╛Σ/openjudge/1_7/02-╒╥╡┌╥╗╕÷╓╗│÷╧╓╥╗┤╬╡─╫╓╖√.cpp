#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s[100005],b[300];
int main(){
  scanf("%s",s+1);
  int len = strlen(s+1);
  for(int i = 1; i <= len; i++)
    b[s[i]]++;
  for(int i = 1; i <= len ; i++)
    if(b[s[i]] == 1){
      printf("%c\n",s[i]);
      return 0;
    }
  printf("no\n");
  return 0;
}
