#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
char s[105][105],a[105],b[105],temp;
int n;
int main(){
  while(temp!='\n'){
    scanf("%s",s[n]);
    n++;
    temp=getchar();
  }
  scanf("%s%s",a,b);
  for(int i=0;i<n;i++)
    if(strcmp(s[i],a)==0)
      printf("%s ",b);
    else
      printf("%s ",s[i]);
  return 0;
}
