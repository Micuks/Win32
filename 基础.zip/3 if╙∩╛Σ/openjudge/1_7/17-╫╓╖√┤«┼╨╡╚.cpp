#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[10000000],b[10000000],p[10000000],q[10000000];
int ca = -1,cb = -1;
int main(){
  cin.getline(a,10000000);
  cin.getline(b,10000000);
  int lena = strlen(a);
  int lenb = strlen(b);

  for(int i = 0; i < lena; i++)
    if(a[i] >= 'A' && a[i] <= 'Z') p[++ca] = a[i] + 32;
    else if(a[i] >= 'a' && a[i] <= 'z') p[++ca] = a[i];
  for(int i = 0; i < lenb; i++)
    if(b[i] >= 'A' && b[i] <= 'Z') q[++cb] = b[i] + 32;
    else if(b[i] >= 'a' && b[i] <= 'z') q[++cb] = b[i];

  if(strcmp(p,q) == 0) {printf("YES");return 0;}
  else printf("NO\n");
  return 0;
}
