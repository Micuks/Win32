#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
char a[5][305],ch;
int t,i,j,la,lb;
int main(){
  ch = getchar();
  while(ch != '\n'){
    if(ch != ','){
      a[t][i++] = ch;
    }
    else {t++; i = 0;}
    ch = getchar();
  }
  // if(!strstr(a[0],a[1])) {printf("-1\n");return 0;}
  la = strstr(a[0],a[1]) - a[0];

  int len = strlen(a[0]);int lena = strlen(a[1]);int lenb= strlen(a[2]);

  reverse(a[0], a[0] + len);reverse(a[2], a[2] + lenb);
  lb = len - (strstr(a[0],a[2]) - a[0] + lenb - 1) - 1;
  // if(strstr(a[0],a[2])) {printf("-1\n");return 0;}


  if(la + lena - 1 >= lb){
    printf("-1\n");return 0;
  }
  else
    printf("%d\n",lb - (la + lena));
  return 0;
}
// a b c d 1 2 3 a b 8 '10' 8 8 e f g '16' h i j 4 5 e f 6 7 k l
// 26 - 5
