#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s[300],p[300];
int main(){
  scanf("%s",s+1);
  int len = strlen(s+1);
  for(int i = 1; i <= len; i++){
    if(s[i] == 'A')
      p[i] = 'T';
    else if(s[i] == 'T')
      p[i] = 'A';
    else if(s[i] == 'G')
      p[i] = 'C';
    else if(s[i] == 'C')
      p[i] = 'G';
  }
  printf("%s\n",p+1);
  return 0;
}
