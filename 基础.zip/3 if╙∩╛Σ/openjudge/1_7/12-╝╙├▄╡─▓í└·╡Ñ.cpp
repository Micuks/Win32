#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
char s[55],p[55];
int main(){
  scanf("%s",s+1);
  int len = strlen(s+1);
  reverse(s + 1, s + len + 1);//reverse
  for(int i = 1; i <= len ; i++){
    if(s[i] >= 'A' && s[i] <= 'Z'){//turn to lower
      if(s[i] + 3 > 64 + 26)
        p[i] = s[i] + 3 - 26 + 32;
      else
        p[i] = s[i] + 3 + 32;
    }
    else
      if(s[i] + 3 > 96 + 26)//turn to upper
        p[i] = s[i] + 3 - 26 - 32;
      else
        p[i] = s[i] + 3 - 32;
  }
  printf("%s\n",p+1);
  return 0;
}
// a b c d e f g h i j k l m n o p q r s t u v w x y z
// GSOOWFASOq
// gsoowfasoq
// jvrrzidvrt
// Trvdizrrvj
//
// qOSAFWOOSG
