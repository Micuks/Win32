#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[5][305],ch;
int t,i,j,la,lb;
int main(){
  ch = getchar();
  while(ch != '\n'){
    if(ch != ','){
      a[t][i++] = ch;
    }
    else {t++; i = 0;}
    ch = getchar();
  }


  la = strstr(a[0],a[1]) - a[0];
  // cout<<la<<endl;

  while( strstr(a[0] + j, a[2]) ){
    lb = strstr(a[0] + j, a[2]) - a[0];//从下一个位置找
    j = lb + 1;
  }
  // cout<<lb<<endl;

  int lena = strlen(a[1]);
  if(la + lena - 1 >= lb){
    printf("-1\n");return 0;
  }
  else
    printf("%d\n",lb - (la + lena));
  return 0;
}
