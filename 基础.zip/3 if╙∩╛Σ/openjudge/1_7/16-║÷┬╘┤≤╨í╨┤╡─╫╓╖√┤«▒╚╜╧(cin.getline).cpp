#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[85],b[85];
int main(){
  cin.getline(a,85);
  cin.getline(b,85);
  int lena = strlen(a);
  int lenb = strlen(b);
  // if(lena > lenb) {printf(">\n");return 0;}
  // if(lena < lenb) {printf("<\n");return 0;}
  for(int i = 0; i < lena; i++)
    if(a[i] >= 'A' && a[i] <= 'Z') a[i] = a[i] + 32;
  for(int i = 0; i < lenb; i++)
    if(b[i] >= 'A' && b[i] <= 'Z') b[i] = b[i] + 32;
  if(strcmp(a,b) == 0) {printf("=\n");return 0;}
  else if(strcmp(a,b) < 0) {printf("<\n");return 0;}
  else {printf(">\n");return 0;}
  return 0;
}
