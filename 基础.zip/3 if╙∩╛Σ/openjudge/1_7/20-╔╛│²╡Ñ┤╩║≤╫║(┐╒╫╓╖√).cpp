#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[33];
int main(){
  int len;
  scanf("%s",a);
  len=strlen(a);
  if(a[len-2]=='e' && a[len-1]=='r') a[len-1]=a[len-2]=0;
  else if(a[len-2]=='l' && a[len-1]=='y') a[len-1]=a[len-2]=0;
  else if(a[len-3]=='i' && a[len-2]=='n' && a[len-1]=='g') a[len-1]=a[len-2]=a[len-3]=0;
  cout<<a;
  return 0;
}
