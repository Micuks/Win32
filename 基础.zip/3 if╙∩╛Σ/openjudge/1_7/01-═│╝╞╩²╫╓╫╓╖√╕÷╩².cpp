#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int cnt;
int main(){
  char c = getchar();
  while(c != '\n'){
    if(c >= '0' && c <= '9')
      cnt++;
    c = getchar();
  }
  printf("%d\n",cnt);
  return 0;
}
