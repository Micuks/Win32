#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[205],b[205];
int main(){
  scanf("%s%s",a,b);
  if(strstr(a,b)){
    printf("%s is substring of %s\n",b,a);
    // printf("%s\n",strstr(a,b));
    return 0;
  }
  if(strstr(b,a)){
    printf("%s is substring of %s\n",a,b);return 0;
  }
  printf("No substring\n");
  return 0;
}
