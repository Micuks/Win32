#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int t;
char s[205];
int main(){
  while(scanf("%s",s) != EOF){
    printf("%s ",s);
  }
  return 0;
}
