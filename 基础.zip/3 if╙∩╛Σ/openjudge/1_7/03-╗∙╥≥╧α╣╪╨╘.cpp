#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
double n;
int cnt;
char a[505],b[505];
int main(){
  scanf("%lf",&n);
  scanf("%s%s",a+1,b+1);
  int len = strlen(a+1);
  for(int i = 1; i <= len; i++){
    if(a[i] == b[i]) cnt++;
  }
  if(cnt*1.0/len > n) printf("yes\n");
  else printf("no\n");
  return 0;
}
