#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
string s,sa,sb;
int main(){
  getline(cin,s,',');
  getline(cin,sa,',');
  getline(cin,sb);
  int la,lb;
  la = s.find(sa);
  lb = s.rfind(sb);
  int lena = sa.size();
  if(la == -1 || lb == -1 || la > lb)printf("-1\n");
  else printf("%d\n",lb - (la + lena - 1) - 1);
  return 0;
}
