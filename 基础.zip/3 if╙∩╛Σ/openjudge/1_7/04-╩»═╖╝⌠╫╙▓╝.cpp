#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
char a[15], b[15];
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%s%s",a+1,b+1);
    if((a[1] == 'R' && b[1] == 'S') || (a[1] == 'S' && b[1] == 'P') || (a[1] == 'P' && b[1] == 'R')){
      printf("Player1\n");
    }
    else if((b[1] == 'R' && a[1] == 'S') || (b[1] == 'S' && a[1] == 'P') || (b[1] == 'P' && a[1] == 'R')){
      printf("Player2\n");
    }
    else
      printf("Tie\n");
  }
  return 0;
}
