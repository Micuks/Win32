#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char c;
int cnt = 1;
int main(){
  c = getchar();
  while(c != EOF){//maybe no '\n'
    if((c >= 'a' && c < 'z') || (c >= 'A' && c < 'Z'))
      printf("%c",c + 1);
    else if(c == 'z') printf("a");
    else if(c == 'Z') printf("A");
    else printf("%c",c);
    c = getchar();
    cnt++;
  }
  // printf("%s\n",b+1);
  return 0;
}
