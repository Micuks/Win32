#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char b[105],cnt,a,p,c;
int main(){
  c = getchar(); p = c; a = c;
  c = getchar();
  while(c != '\n'){
    printf("%c",p + c);//pre + current
    p = c;
    c = getchar();
  }
  printf("%c\n",a + p);
  return 0;
}
