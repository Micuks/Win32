#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<map>
using namespace std;
int n,fl;
string p,q,w,u;
int main(){
  std::ios::sync_with_stdio(false);
  cin>>u>>n;
  for(int i = 1; i <= n; i++){
    cin>>p>>q>>w;
    if(w != u) continue;
    fl = 1;
    int len = q.size();
    for(int j = 0; j < len; j++){
      if(q[j] >= 'a' && q[j] <= 'z')//关联性
        q[j] -= 32;
      else if(q[j] >= 'A' && q[j] <= 'Z')
        q[j] += 32;
    }
    cout<<p<<" "<<q<<endl;
  }
  if(!fl) cout<<"empty"<<endl;
  return 0;
}
