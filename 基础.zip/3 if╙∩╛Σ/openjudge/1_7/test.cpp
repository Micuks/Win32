#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s1[31],s2[31],s3[62],s4[62];
int main(){
  scanf("%s%s",s1,s2);
  strcat(s3,s1);strcat(s3,s1);
  if(strstr(s3,s2)){
    cout<<"true";
    return 0;
  }
  strcat(s4,s2);strcat(s4,s2);
  if(strstr(s4,s1)){
    cout<<"true";
    return 0;
  }
  cout<<"false";
  return 0;
}
