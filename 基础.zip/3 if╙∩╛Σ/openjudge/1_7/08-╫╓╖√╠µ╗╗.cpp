#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s[35],p,v,b[35];
int main(){
  scanf("%s %c %c",s+1,&p,&v);
  int len = strlen(s+1);
  for(int i = 1; i <= len; i++){
    if(s[i] == p)
      b[i] = v;
    else b[i] = s[i];
  }
  printf("%s\n",b+1);
  return 0;
}
