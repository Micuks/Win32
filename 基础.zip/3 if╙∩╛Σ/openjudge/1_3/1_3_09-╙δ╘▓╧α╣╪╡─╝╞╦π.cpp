#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
double r,pi=3.14159;
int main(){
  scanf("%lf",&r);
  printf("%0.4lf %0.4lf %0.4lf\n",2*r,2*pi*r,pi*r*r);
  return 0;
}
