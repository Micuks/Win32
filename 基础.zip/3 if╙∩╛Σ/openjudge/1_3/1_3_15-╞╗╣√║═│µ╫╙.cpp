#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,x,y;
double pi = 3.14159;
int main(){
  scanf("%d%d%d",&n,&x,&y);
  printf("%d\n", n - int(ceil( y*1.0 / x)));
  return 0;
}
