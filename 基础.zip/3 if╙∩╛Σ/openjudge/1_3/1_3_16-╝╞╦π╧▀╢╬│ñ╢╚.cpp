#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
double xa,ya,xb,yb;
int main(){
  scanf("%lf%lf%lf%lf",&xa,&ya,&xb,&yb);
  printf("%0.3lf\n", sqrt((xa - xb) * (xa - xb) + (ya - yb) * (ya - yb)));
  return 0;
}
