#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int a ,b , an , n;
int main(){
  scanf("%d%d%d",&a,&b,&n);
  an = a + (b - a)*(n - 1);
  printf("%d\n",an);
  return 0;
}
