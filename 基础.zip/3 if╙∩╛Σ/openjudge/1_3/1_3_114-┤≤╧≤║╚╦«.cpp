#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int h,r;
double pi = 3.14159;
int main(){
  scanf("%d%d",&h,&r);
  printf("%d",int(ceil(20000.0 / (pi * r * r * h))));
  return 0;
}
