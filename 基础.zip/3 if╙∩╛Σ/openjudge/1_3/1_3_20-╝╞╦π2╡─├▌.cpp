#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
#define ll long long
int n;
int main(){
  scanf("%d",&n);
  printf("%d\n",(1 << n));
  return 0;
}
