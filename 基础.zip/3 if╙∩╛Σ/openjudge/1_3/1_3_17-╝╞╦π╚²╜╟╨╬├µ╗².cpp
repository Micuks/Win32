#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
double xa,ya,xb,yb,xc,yc;
double a,b,c,q,s;
int main(){
  scanf("%lf%lf%lf%lf%lf%lf",&xa,&ya,&xb,&yb,&xc,&yc);
  a = sqrt((xa - xb) * (xa - xb) + (ya - yb) * (ya - yb));
  b = sqrt((xa - xc) * (xa - xc) + (ya - yc) * (ya - yc));
  c = sqrt((xc - xb) * (xc - xb) + (yc - yb) * (yc - yb));
  q = (a + b + c)/2;
  s = sqrt(q *(q - a) *(q - b) *(q - c));
  printf("%0.2lf\n",s);
  return 0;
}
