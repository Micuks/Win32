#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
double f,c;
int main(){
  scanf("%lf",&f);
  c = 5 * (f - 32) /9;
  printf("%0.5lf",c);
  return 0;
}
