#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a,b;
int main(){
  scanf("%d%d",&a,&b);
  printf("%0.3f%%",b*1.0/a*100);
  return 0;
}
