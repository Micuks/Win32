#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a,b;
int main(){
  scanf("%d%d",&a,&b);
  printf("%0.9lf",a*1.0/b);
  return 0;
}
