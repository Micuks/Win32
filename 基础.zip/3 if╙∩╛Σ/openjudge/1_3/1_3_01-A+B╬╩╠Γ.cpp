#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a,b;
int main(){
  scanf("%d%d",&a,&b);
  printf("%d",a+b);
  return 0;
}
