#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
float ra,rb;
int main(){
  scanf("%f%f",&ra,&rb);
  printf("%0.2lf\n",1 / (1 / ra + 1 / rb ));
  return 0;
}
