#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;
int main(){
  scanf("%d",&n);
  printf("%d%d%d",n%10,n/10%10,n/100);
  return 0;
}
