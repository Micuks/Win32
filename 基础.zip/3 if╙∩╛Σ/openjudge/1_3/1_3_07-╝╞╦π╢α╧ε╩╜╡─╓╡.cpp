#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
double x,a,b,c,d,y;
int main(){
  scanf("%lf%lf%lf%lf%lf",&x,&a,&b,&c,&d);
  y = a * x * x * x + b * x * x + c * x + d;
  printf("%0.7lf",y);
  return 0;
}
