#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
double a,b;
int main(){
  scanf("%lf%lf",&a,&b);
  printf("%g\n",a - int(a / b) * b);
  return 0;
}
