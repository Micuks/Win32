#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
double r, pi = 3.14;
int main(){
  scanf("%lf",&r);
  printf("%0.2lf",4.0/3 * pi * r * r * r);
  return 0;
}
