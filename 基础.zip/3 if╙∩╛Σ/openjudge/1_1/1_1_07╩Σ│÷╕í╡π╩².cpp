#include<iostream>
#include<cstdio>
using namespace std;
double a;
int main(){
  scanf("%lf",&a);
  printf("%f\n",a);
  printf("%0.5f\n",a);
  printf("%e\n",a);//科学计数法
  printf("%g\n",a);//哪个占位少输出哪个
  return 0;
}
/*
%g 除无用0以%f%e中较短的输出宽度输出单，双精度实数
double a=1000000000;
double b=123.456;
printf("%e\n",a);
printf("%f\n",a);
printf("%g\n",a);
printf("%e\n",b);
printf("%f\n",b);
printf("%g\n",b);
*/
