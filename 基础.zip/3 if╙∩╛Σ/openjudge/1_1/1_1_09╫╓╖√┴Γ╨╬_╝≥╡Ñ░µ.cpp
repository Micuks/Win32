#include<iostream>
#include<cstdio>
using namespace std;
int main(){
  printf(
  "  *\n"
  " ***\n"
  "*****\n"
  " ***\n"
  "  *\n");
  return 0;
}
