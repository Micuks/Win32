#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
  printf("F E\n");
  return 0;
}
