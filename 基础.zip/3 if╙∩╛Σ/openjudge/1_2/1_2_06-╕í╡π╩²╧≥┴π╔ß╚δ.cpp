#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
float a;
int main(){
  scanf("%f",&a);
  printf("%d\n",int(a));
  return 0;
}
