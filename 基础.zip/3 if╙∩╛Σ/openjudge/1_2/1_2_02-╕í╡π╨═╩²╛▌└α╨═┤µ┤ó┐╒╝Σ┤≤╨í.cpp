#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
float a;double b;
int main(){
  printf("%d %d\n",sizeof(a),sizeof(b));
  return 0;
}
