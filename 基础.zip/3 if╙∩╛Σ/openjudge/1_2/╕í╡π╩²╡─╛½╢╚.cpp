#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
float a;
double b;
long double c;
int main(){
  scanf("%f%lf%Lf",&a,&b,&c);
  printf("%0.25f\n%0.25lf\n%0.25Lf\n",a,b,c);
  return 0;
}
//1.12345678998765432112345
