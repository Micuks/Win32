#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
  printf("%d\n",sizeof("Hello, World!"));
  return 0;
}
