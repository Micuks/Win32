#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
bool a;char b;
int main(){
  printf("%d %d",sizeof(a),sizeof(b));
  return 0;
}
