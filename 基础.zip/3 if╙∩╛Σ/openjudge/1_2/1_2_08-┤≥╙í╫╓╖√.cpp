#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a;
int main(){
  scanf("%d",&a);
  printf("%c\n",char(a));
  return 0;
}
