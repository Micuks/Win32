#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a;
bool b;
int main(){
  scanf("%d",&a);
  b = a;
  a = b;
  printf("%d\n",a);
  return 0;
}
