#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
short a;int b;
int main(){
  printf("%d %d\n",sizeof(b),sizeof(a));
  return 0;
}
