#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
short b;
int a;
int main(){
  scanf("%d",&a);
  b = a;
  printf("%d",b);
  return 0 ;
}
/*
32768
10000000 00000000
 1111111 11111111
+               1
-----------------
10000000 00000000
-32768

32769
10000000 00000001
 1111111 11111110
+               1
----------------
 1111111 11111111
-32767
*/
