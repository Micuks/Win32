#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char a;
int main(){
  scanf("%c",&a);
  printf("%d\n",int(a));
  return 0;
}
