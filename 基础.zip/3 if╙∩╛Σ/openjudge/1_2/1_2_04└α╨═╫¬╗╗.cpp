#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
  printf("D C\n");
  return 0;
}
