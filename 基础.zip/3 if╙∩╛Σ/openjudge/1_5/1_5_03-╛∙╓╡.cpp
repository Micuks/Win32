#include<iostream>
#include<cstdio>
using namespace std;
int n;
double x,sum;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%lf",&x);
    sum += x;
  }
  printf("%0.4lf",sum*1.0 / n);
  return 0;
}
