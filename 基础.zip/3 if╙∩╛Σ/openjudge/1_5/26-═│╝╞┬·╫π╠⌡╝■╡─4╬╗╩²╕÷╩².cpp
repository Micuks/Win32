#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,x,g,s,b,q,cnt;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n ; i++){
    scanf("%d",&x);
    g = x % 10;
    s = x /10 % 10;
    b = x / 100 % 10;
    q = x /1000;
    if(g - q - b - s > 0 ) cnt++;
  }
  printf("%d\n",cnt);
 return 0;
}
