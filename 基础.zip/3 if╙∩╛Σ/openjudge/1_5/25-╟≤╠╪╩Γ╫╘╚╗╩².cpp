#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int p,q;
int main(){
  //for(int i = 100; i <= 999 ;i++)不因定是七进制数
    for(int i = 1 ; i <= 7; i++)//baiwei
      for(int j = 0; j <= 7; j++)
        for(int k = 0; k <= 7; k++){
          p = i * 7 * 7 + j * 7 + k;
          q = k * 9 * 9 + j * 9 + i;
          if(p == q){
            printf("%d\n",p);
            printf("%d%d%d\n",i,j,k);
            printf("%d%d%d\n",k,j,i);
          }
        }
 return 0;
}
