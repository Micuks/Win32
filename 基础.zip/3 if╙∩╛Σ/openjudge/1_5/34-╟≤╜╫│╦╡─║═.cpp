#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,sum, tmp = 1;
int main(){
 scanf("%d",&n);
 for(int i = 1; i <= n; i++){
   tmp = tmp * i;
   sum += tmp;
 }
 printf("%d\n",sum);
 return 0;
}
