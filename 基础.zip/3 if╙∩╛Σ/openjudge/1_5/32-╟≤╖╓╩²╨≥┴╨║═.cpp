#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,tmp;
double sum = 0,p,q;
int main(){
  scanf("%d",&n);
  sum = 2.0,p = 1,q = 2;
  for(int i = 2; i <= n; i++){
    tmp = p ;
    p = q;
    q = q + tmp;
    sum += q/p;
  }
  printf("%0.4lf\n",sum);
 return 0;
}
