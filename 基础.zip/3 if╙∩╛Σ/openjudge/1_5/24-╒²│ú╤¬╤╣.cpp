#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int p = 1,cnt,n,x,y,ans;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%d%d",&x,&y);
    if(x >= 90 && x <= 140 && y >= 60 && y <=90)
      cnt++;
    else
      cnt = 0;
    ans = max(ans,cnt);
  }
  printf("%d\n",ans);
 return 0;
}
