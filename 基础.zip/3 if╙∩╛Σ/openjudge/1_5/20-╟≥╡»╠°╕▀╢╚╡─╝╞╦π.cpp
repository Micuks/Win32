#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
double sum,h;
int main(){
  scanf("%lf",&h);
  for(int i = 1; i <= 10; i++){
    sum += h;
    h = h /2.0;
    sum += h;
  }
  // cout<<h<<endl;
  printf("%g\n%g\n",sum - h,h);
 return 0;
}
