#include<iostream>
#include<cstdio>
using namespace std;
int n,x,mx = 0 ,mn = 1e9;
int main(){
  scanf("%d",&n);
  // printf("%d\n", mn);
  for(int i = 1; i <= n; i++){
    scanf("%d",&x);
    mx = max(mx, x);
    mn = min(mn, x);
  }
  printf("%d",mx - mn);
  return 0;
}
