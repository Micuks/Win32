#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
double a;
int main(){
  scanf("%lf%d",&a,&n);
  for(int i = 1; i <= n; i++){
    a = a * (1 + 0.001);
  }
  printf("%0.4lf\n", a);
 return 0;
}
