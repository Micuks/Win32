#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,b[5005],cnt,a[5005];
int main(){
  scanf("%d%d",&n,&m);
  for(int i = 2; i <= m; i++){
    for(int j = i; j <= n; j++){
      if(j % i == 0){
        b[j] ^= 1;
      }
    }
  }
  for(int i = 1; i <= n; i++){
    if(b[i] == 0) {
      a[++cnt] = i;
    }
  }
  for(int i = 1; i <= cnt - 1; i++)
    printf("%d,", a[i]);
  printf("%d\n", a[cnt]);
  return 0;
}
//怎么保证最后那个数没有逗号？
