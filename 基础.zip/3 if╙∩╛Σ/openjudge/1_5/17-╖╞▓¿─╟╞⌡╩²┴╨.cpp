#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int a,b,c,k;
int main(){
  a = 1;b = 1;
  scanf("%d",&k);
  if(k == 1 || k == 2) {
    printf("1\n");return 0;
  }
  for(int i = 3; i <= k ;i++){
    c = a + b;
    a = b;
    b = c;
  }
  printf("%d\n",c);
 return 0;
}
