#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,t,sum;
int main(){
  scanf("%d",&n);
  int i;
  for(i = 1; t + i <= n; i++){
    sum += i * i;
    t += i;
  }
  printf("%d\n",sum + i * (n - t));
  return 0;
}
// 1 2 3 4 5 6 7 8 9 10 11 12
// 1 2 2 3 3 3 4 4 4 4   5  5
