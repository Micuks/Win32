#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,k;
double my = 200,sum;
int main(){
  scanf("%d%d",&n,&k);
  if(n > my){
    printf("1\n");return 0;
  }
  sum = n;
  for(int i = 2 ; i <= 20; i++){
    my = my * (1 + k/100.0);
    sum += n;
    // cout<<my<<endl;
    // cout<<sum<<endl;
    if(sum > my){
      printf("%d\n",i);
      return 0;
    }
  }
  printf("Impossible\n");
 return 0;
}
