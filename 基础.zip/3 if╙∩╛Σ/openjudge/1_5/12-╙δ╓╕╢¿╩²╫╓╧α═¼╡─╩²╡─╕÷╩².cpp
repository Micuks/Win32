#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,x,m,cnt;
int main(){
  scanf("%d%d", &n,&m);
  for(int i = 1; i <= n; i++){
    scanf("%d",&x);
    if(x == m)
      cnt++;
  }
  printf("%d\n",cnt);
 return 0;
}
