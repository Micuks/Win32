#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int r,y;
double m;
int main(){
  scanf("%d%lf%d",&r,&m,&y);
  for(int i = 1; i <= y; i++){
    m = m * (1 + r/100.0);
  }
  printf("%d\n",int(m) );
 return 0;
}
