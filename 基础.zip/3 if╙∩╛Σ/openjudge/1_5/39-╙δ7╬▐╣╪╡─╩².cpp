#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,ans,sum;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
      sum += i*i;
      if(i % 7 == 0 || i % 10 == 7 || i / 10 == 7){
        // printf("%d\n",i );
        ans += i*i;
      }
  }
  printf("%d\n",sum - ans);
  return 0;
}
