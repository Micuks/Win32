#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,w,v;
double p,q;
int main(){
  scanf("%d\n",&n);
  scanf("%d%d",&w,&v);
  p = v * 1.0 / w;
  for(int i = 2; i <= n; i++){
    scanf("%d%d",&w,&v);
    q = v * 1.0 / w;
    if(q - p > 0.05 ) printf("better\n");
    else if(p - q > 0.05) printf("worse\n");
    else printf("same\n");
  }
 return 0;
}
