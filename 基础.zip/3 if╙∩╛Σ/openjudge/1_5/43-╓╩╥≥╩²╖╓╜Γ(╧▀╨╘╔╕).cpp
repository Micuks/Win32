#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<cmath>
using namespace std;
int n,m,cnt,prm[100005],f[100005];
int main(){
  scanf("%d",&n);
  m = sqrt(n);
  for(int i = 2; i <= m; i++){
    if(!f[i]) prm[++cnt] = i;
    for(int j = 1; j <= cnt && prm[j] * i <= m; j++){
      f[ prm[j] * i ] = 1;
      if(i % prm[j] == 0){
        break;
      }
    }
  }
  // for(int i = 1; i <= cnt; i++){
  //   printf("%d ",prm[i]);
  // }
  // printf("\n");
  for(int i = 1; prm[i] <= sqrt(n); i++){
    if(n % prm[i] == 0){
      printf("%d\n",n/prm[i]);
      break;
    }

  }
  return 0;
}
