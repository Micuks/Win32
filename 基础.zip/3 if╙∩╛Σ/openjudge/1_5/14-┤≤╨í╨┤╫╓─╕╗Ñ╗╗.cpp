#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char c;
int main(){
  c = getchar();
  while(c != EOF){
    if(c >= 'a' && c <= 'z'){
      printf("%c",c - 32);
    }
    else if(c >= 'A' && c<= 'Z')
      printf("%c",c + 32);
    else printf("%c",c);
    c = getchar();
  }
  return 0;
}
