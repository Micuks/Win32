#include<iostream>
#include<cstdio>
using namespace std;
int n,x,mx;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%d",&x);
    mx = max(mx, x);
  }
  printf("%d",mx);
  return 0;
}
