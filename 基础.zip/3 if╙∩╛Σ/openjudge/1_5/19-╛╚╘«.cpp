#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,p;
double x,y,sum;
int main(){
  scanf("%d",&n);
  for(int i = 1 ; i <= n; i++){
    scanf("%lf%lf%d",&x,&y,&p);
    sum += 2 * sqrt(x * x + y * y) / 50.0 + 1.5 * p;
  }
  printf("%d\n",int(sum + 1.0));
 return 0;
}
