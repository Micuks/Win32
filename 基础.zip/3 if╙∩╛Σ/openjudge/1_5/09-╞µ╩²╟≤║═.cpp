#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int l,r,sum;
int main(){
  scanf("%d%d",&l,&r);
  for(int i = l ; i <= r; i++)
    if(i % 2 == 1)
      sum += i;
  printf("%d\n",sum);
 return 0;
}
