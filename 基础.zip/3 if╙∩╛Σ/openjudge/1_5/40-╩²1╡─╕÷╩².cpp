#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int tmp,cnt,l,r;
int main(){
  scanf("%d%d",&l,&r);
  for(int i = l; i <= r; i++){
    tmp = i;
    while(tmp){
      if(tmp % 10 == 2) cnt++;
      tmp /= 10;
    }
  }
  printf("%d\n",cnt);
  return 0;
}
