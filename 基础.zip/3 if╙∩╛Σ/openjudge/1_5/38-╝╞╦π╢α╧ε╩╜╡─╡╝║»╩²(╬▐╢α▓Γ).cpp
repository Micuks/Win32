#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int t,n,c[105],b[105];
int main(){
  // scanf("%d",&t);
  // while(t--){
    scanf("%d",&n);
    for(int i = n; i >= 0; i--){
      scanf("%d",&c[i]);
      b[i] = i * c[i];
    }
    if(n == 0) printf("0\n");
    for(int i = n; i >= 1; i--)
      printf("%d ",b[i]);
    printf("\n");
  // }
  return 0;
}
