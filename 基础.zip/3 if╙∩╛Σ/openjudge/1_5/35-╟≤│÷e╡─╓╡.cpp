#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
double tmp = 1,sum = 1.0;
int main(){
 scanf("%d",&n);
 for(int i = 1; i <= n; i++){
   tmp = tmp * i;
   sum += 1.0/tmp;
 }
 printf("%0.10lf\n",sum);
 return 0;
}
