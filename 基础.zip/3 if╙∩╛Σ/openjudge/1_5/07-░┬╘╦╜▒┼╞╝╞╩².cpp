#include<iostream>
#include<cstdio>
using namespace std;
int n,a,b,c,suma,sumb,sumc;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%d%d%d",&a,&b,&c);
    suma += a;
    sumb += b;
    sumc += c;
  }
  printf("%d %d %d %d",suma,sumb,sumc,suma + sumb + sumc);
  return 0;
}
