#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,cnt,k;
int main(){
  scanf("%d%d",&m,&k);
  n = m;
  while(n){
    if(n % 10 == 3)cnt++;
    n /= 10;
  }
  if(m % 19 == 0 && cnt == k)
    printf("YES\n");
  else
    printf("NO\n");
 return 0;
}
