#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n ,prm[200000],cnt,fl[200000];
int main(){
  scanf("%d",&n);
  for(int i = 2; i <= 200000; i++){
    if(!fl[i]) prm[++cnt] = i;
    for(int j = 1; j <= cnt && i * prm[j] <= 200000; j++){
      fl[ i * prm[j] ] = 1;
      if(i % prm[j] == 0)break;
    }
  }
  // for(int i = 1; i <= cnt; i++)
  //   printf("%d ",prm[i]);
  printf("%d\n",prm[n]);
  return 0;
}
