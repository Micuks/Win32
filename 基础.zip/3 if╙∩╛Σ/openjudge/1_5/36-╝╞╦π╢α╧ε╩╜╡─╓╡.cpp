#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
float x, tmp, sum;
int n;
int main(){
  scanf("%f%d",&x,&n);
  sum = 1; tmp = 1;
  for(int i = 1; i <= n; i++){
    tmp *= x;
    sum += tmp;
  }
  printf("%0.2f\n",sum);
 return 0;
}
