#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,k;
double s;
int main(){
  scanf("%d",&k);
  for(int i = 1; ; i++){
    s += 1.0/i;//forget 1.0
    // cout<<s<<endl;
    if(s > k * 1.0){
      n = i;
      break;
    }
  }
  printf("%d\n",n);
  return 0;
}
