#include<iostream>
#include<cstdio>
using namespace std;
int n,x,sum;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%d",&x);
    sum += x;
  }
  printf("%d %0.5lf",sum,sum*1.0 / n);
  return 0;
}
