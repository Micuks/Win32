#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,ans;
int main(){
  scanf("%d",&n);
  while(n){
    ans = ans * 10 + (n % 10);
    n /= 10;
  }
  printf("%d\n",ans);
 return 0;
}
