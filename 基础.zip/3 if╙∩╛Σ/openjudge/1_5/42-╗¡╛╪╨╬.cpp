#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int h,w,p;
char c,a[15][15];
int main(){
  scanf("%d%d %c%d",&h,&w,&c,&p);
  for(int i = 1; i <= h; i++)
    for(int j = 1; j <= w; j++)
      a[i][j] = c;
  if(p == 0){
    for(int i = 2; i <= h-1; i++)
      for(int j = 2; j <= w - 1; j++)
        a[i][j] = ' ';
  }
  for(int i = 1; i <= h; i++){
    for(int j = 1; j <= w; j++)
       printf("%c",a[i][j]);
    printf("\n");
  }
  return 0;
}
