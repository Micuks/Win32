#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int m,n,x,p;
int main(){
  scanf("%d%d%d",&m,&n,&x);
  do{
    if(n%m == 0) p = m/n;
    else p = m/n + 1;
    x -= p;
    n += m/n;
  }while(x >= p);
  printf("%d\n",n);
  return 0;
}

// 能量元素 体力  战斗
// -1-1-1  +5   4
// -1-1    +5   5
// -1      +5   6
// -1      +5   6
// -1      +5   6
