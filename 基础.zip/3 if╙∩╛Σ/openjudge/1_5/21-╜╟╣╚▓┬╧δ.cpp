#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
long long n;
int main(){
  scanf("%lld",&n);
  while(n != 1){
    if(n % 2 == 1){
      printf("%lld*3+1=",n);
      printf("%lld\n",n = n * 3 + 1);
    }
    else{
      printf("%lld/2=",n);
      printf("%lld\n",n = n/2);
    }
  }
  printf("End\n");
  return 0;
}
//Out Limit
