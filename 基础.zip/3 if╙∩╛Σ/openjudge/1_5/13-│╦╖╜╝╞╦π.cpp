#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int a,n,ans=1;
int main(){
  scanf("%d%d",&a, &n);
  for(int i = 1; i <= n; i++)
    ans *= a;
  printf("%d\n",ans );
 return 0;
}
