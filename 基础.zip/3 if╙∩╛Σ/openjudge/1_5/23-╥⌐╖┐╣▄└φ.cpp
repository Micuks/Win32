#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int m,n,sum,x,cnt;
int main(){
  scanf("%d%d",&m,&n);
  sum = m;
  for(int i = 1; i <= n ; i++){
    scanf("%d",&x);
    if(sum - x >= 0 ){
      cnt++;
      sum -= x;
    }
  }
  printf("%d\n",n - cnt);
 return 0;
}
