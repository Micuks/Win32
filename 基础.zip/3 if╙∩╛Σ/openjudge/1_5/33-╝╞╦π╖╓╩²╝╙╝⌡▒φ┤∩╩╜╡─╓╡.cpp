#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n, p = 1;
double sum = 0;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    sum += (p*1.0) / i;
    p = -p;
  }
  printf("%0.4lf\n",sum);
 return 0;
}
