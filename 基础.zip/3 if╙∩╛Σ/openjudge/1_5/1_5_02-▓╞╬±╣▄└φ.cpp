#include<iostream>
#include<cstdio>
using namespace std;
double x,sum;
int main(){
  for(int i = 1; i <= 12; i++){
    scanf("%lf",&x);
    sum += x;
  }
  printf("$%0.2lf",sum*1.0 / 12);
  return 0;
}
