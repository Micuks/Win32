#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,cnta,cntb,cntc,x;
int main(){
  scanf("%d",&n);
  for(int i = 1; i <= n; i++){
    scanf("%d",&x);
    if(x == 1) cnta++;
    if(x == 5) cntb++;
    if(x == 10) cntc++;
  }
  printf("%d\n%d\n%d\n",cnta,cntb,cntc);
 return 0;
}
