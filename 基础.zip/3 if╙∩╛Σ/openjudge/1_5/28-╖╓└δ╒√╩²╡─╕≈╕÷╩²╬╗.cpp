#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int main(){
  scanf("%d",&n);
  while(n){
    printf("%d ",n%10);
    n /= 10;
  }
 return 0;
}
