#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,x,sum;
int main(){
  scanf("%d",&n);
  for(int i = 1 ;i <= n - 1; i++){
    scanf("%d",&x);
    sum += x;
  }
  printf("%d\n",(n - 2) * 180 - sum);
 return 0;
}
