#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int p[130000],v[130000],n,i,j,m;
int main()
{
cin>>n;
for(i=2;i<=106000;i++){
if(v[i]==0){
v[i]=i;
p[++m]=i;
}
if(m==n)break;
for(j=1;j<=m;j++)
{
if(p[j]>v[i]||p[j]>106000/i)break;
else v[i*p[j]]=p[j];
}
}
cout<<p[n]<<endl;
}
