#include<bits/stdc++.h>
#define p 10000
using namespace std;
int sum = 0,fl = 0 ,x;
char c, f;
int main(){
	while(scanf("%d",&x) == 1){	
		if(fl == 0) t = x;
		if(c == '*')t = (t * x) % p;
		if(c == '+') sum = (sum + t) % p; t = x;
		scanf("%c",&c);
		fl++;
	}
	cout<<(sum + t) % p<<endl;
	return 0;
} 
//30074*1+20527*5622+426*30359*17917*23238 == 4632
// 2*3+3*4*2+5*5
//426*30359+17917*23238 = 8180
