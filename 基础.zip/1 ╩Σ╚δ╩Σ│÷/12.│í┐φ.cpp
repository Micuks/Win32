#include<iostream>
#include<cstdio> 
using namespace std;
int a,b,c;
int main(){
	scanf("%d%d%d",&a,&b,&c);
	printf("%6d%6d%6d\n",a,b,c);
	printf("%-6d%-6d%-6d",a,b,c);
	return 0;
}

