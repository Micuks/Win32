#include<iostream>
#include<cstdio>
using namespace std;
int a;
int main(){
	cin>>a;
	cout<<a+2<<endl;
	return 0;
}

