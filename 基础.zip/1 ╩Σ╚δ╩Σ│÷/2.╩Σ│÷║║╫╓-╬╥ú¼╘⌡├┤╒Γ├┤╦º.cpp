#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    cout<<"�ң���ô��ô˧"<<endl;
	return 0;
}

