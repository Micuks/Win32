#include<iostream>
#include<cstdio>
#include<cstring> 
using namespace std;
int a;
int main(){
  scanf("%d",&a);
  printf("%c%c%c%c%c",char(a),char(a),char(a),char(a),char(a));
  return 0;
}
