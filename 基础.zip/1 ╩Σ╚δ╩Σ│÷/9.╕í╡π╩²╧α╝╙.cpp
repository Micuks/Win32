#include<iostream>
using namespace std;
float a,b;
int main(){
	cin>>a>>b;//4.324215345 5.89023468743
	cout<<a+b<<endl;
	return 0;
}
