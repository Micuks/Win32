#include<iostream>
using namespace std;
int main(){
	cin>>a>>b;
	cout<<a<<","<<b<<endl;
	c = a + b;
	cout<<c<<endl;
	return 0;
}
