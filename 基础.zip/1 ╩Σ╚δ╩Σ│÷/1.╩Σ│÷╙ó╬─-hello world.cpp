#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    cout<<"hello word"<<endl;
	return 0;
}

