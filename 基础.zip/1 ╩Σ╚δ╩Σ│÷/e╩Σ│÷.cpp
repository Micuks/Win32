#include<iostream>
using namespace std;
double a,b;
int main(){
	printf("%lf\n",905.5243450000);
	printf("%e\n",905.5243450000);
	printf("%g\n",905.5243450000);
	printf("%0.8g\n",905.5243450000); 
	
	printf("%lf\n",0.000035352);
	printf("%e\n",0.000035352);
	printf("%g\n",0.000035352);
	printf("%0.8g\n",0.000035352);
	
	  printf("%g\n", 0.0001234);
	    printf("%g\n", 0.00001234);
	return 0;
}
