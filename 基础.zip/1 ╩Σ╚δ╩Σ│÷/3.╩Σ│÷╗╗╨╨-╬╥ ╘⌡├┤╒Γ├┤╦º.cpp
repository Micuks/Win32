#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    cout<<"��"<<endl;
	cout<<"��ô��ô˧"<<endl;
	return 0;
}

