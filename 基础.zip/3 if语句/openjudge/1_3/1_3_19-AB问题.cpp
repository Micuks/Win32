#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
#define ll long long
int a ,b;
int main(){
  scanf("%d%d",&a,&b);
  // printf("%lld\n",(ll)a * b);
  printf("%lld\n",1ll * a * b);
  return 0;
}
