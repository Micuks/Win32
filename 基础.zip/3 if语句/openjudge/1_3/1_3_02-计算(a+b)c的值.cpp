#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a,b;
int main(){
  scanf("%d%d",&a,&b);
  printf("%d %d\n",a/b,a-(a/b*b));
  // printf("%d %d\n",a/b,a%b);
  return 0;
}
