1.��֪�ַ�����,û�пո�һά��һ��

char s[105];//1h3pp9ax
int main(){
	cin>>m;
	for(int i = 0; i < m; i++){
		cin>>s[i];
		if(s[i] >= '0' && s[i] <= '9') cnt++; 
	}
	cout<<cnt<<endl;
} 
 
   cin>>s;
   scanf("%s",s);
	for(int i = 0; i < m; i++){
		cin>>s[i];
		if(s[i] >= '0' && s[i] <= '9') cnt++; 
	}
  
  char c;
  for(int i = 0; i < m; i++){
  	scanf("%c",&c);
  	if(c >= '0' && c <= '9') cnt++;
  } 
 
  char c;
  for(int i = 0; i < m; i++){
  	 c = getchar();
  	 if(c >= '0' && c <= '9') cnt++;
  } 
  
  string s;
  cin>>s;
	for(int i = 0; i < m; i++){
		cin>>s[i];
		if(s[i] >= '0' && s[i] <= '9') cnt++; 
	}
	cout<<cnt<<endl;
	
2.��֪���ַ����ȣ�û�пո�һά��һ��
	char s[105];//1h3pp9ax
	int main(){
		scanf("%s",s);
		int m = strlen(s); 
		for(int i = 0; i < m; i++){
			if(s[i] >= '0' && s[i] <= '9') cnt++; 
		}
		cout<<cnt<<endl;
	} 
	
	
	char c;
	int t = 0;
	c = getchar();
	while(c != '\n'){
		if(c >= '0' && c <= '9') cnt++;
		t++;
	}

3.��ά����
char s[105][205]; 
for(int i = 0; i < n; i++){
	scanf("%s",s[i]);
}
for(int i = 0; i < n; i++)
	for(int j =0; j < m; j++){
		if(s[i][j] >= '0' && s[i][j] <='9') 
			b[i][j] = 1;
		else 
			b[i][j] = 0;
	}

for(int i = 0; i < n; i++){
	c = getchar();
	int j = 0;
	while(c != '\n'){
		if(c ..) b[i][j] = 1; 
		c = getchar();
		j++;
	}
}
9 p scanf("%d %c",&x,&y);
char y;int x;
cin>>x>>y;
char c;
for(int i = 0; i < n; i++)
	for(int j = 0; j <= m; j++){
		cin>>c;
		if(c..) b[i][j] = 1;
	}
	
1.���пո�һ��
(1) ����
c = getchar();
while(c !='\n'){
	if(c >= 'a' && c <= 'z' || (c>= 'A' && c<='Z')) cnt++;
	c = getchar();	
} 
(2)
char s[1005];
cin.getchar(s,1005);
int len = strlen(s);
for(int i = 0; i < len; i++){
		if(c >= 'a' && c <= 'z' || (c>= 'A' && c<='Z')) cnt++;
}

n�У�ÿ�п��ܺ��пո�
for(int i = 0; i < n; i++){
	cin.getchar(s,1005);
	int len = strlen(s);
	for(int i = 0; i < len; i++){
			if(c >= 'a' && c <= 'z' || (c>= 'A' && c<='Z')) cnt++;
	}
}
