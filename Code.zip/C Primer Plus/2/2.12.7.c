#include <stdio.h>
void s(void){
    printf("Smile!");
}
int main(void){
    s();s();s();printf("\n");
    s();s();printf("\n");
    s();printf("\n");
    getchar();
    return 0;
}
