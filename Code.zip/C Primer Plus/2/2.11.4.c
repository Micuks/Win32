#include <stdio.h>
int main()
{
    int s;
    s = 56;
    printf("There are %d weeks in a year.", s);
    getchar();
    return 0;
}