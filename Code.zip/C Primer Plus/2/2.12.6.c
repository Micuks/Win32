#include <stdio.h>

int main(void)
{
    int toes = 10;
    printf("toes equals to %d;\ndouble toes equals to %d;\ntoes*toes equals to %d.\n",toes,toes*2,toes*toes);
    getchar();
    return 0;
}