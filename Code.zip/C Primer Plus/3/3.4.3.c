#include <stdio.h>
int main(void)
{
    printf("lol \007\n");
    getchar();
    printf("lol\f\n");
    getchar();
    return 0;
}