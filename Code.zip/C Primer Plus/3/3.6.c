#include <stdio.h>
#include <inttypes.h>
//#include <stdint.h>
int main(void)
{
    int32_t me32;
    me32 = 45933945;
    printf("First,assume int32_t is %d\n", me32);
    printf("Next,let's not make any assumptions.\n");
    printf("Instead,use a \"marco\" from inttypes.h: ");
    printf("me32 = %" PRId32 "\n", me32);
    getchar();
    return 0;
}